FT Reader App
=========

This is a basic app to read FT articles. It uses the following Chrome App API's and has the following features.

* Get data on install.
* Store data locally for offline usage.
* Update with new data at 6am every day.
* Speak text to the user.